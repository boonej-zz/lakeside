<?php



/*-----------------------------------------------------------------------------------*/
/* [mp-services]
/*-----------------------------------------------------------------------------------*/

function mp_services($atts, $content = null) {
	extract(shortcode_atts(array(
		"query" => '',
        "category" => '',
		"posts" => '',
		"columns" => '3',
		"layout" => '' /* 0 / modern / classic */,
		"type" => '' /* 0 / boxed */,
	), $atts));
	global $wp_query,$paged,$post;
	$temp = $wp_query;
	$wp_query= null;
	$wp_query = new WP_Query();
	if($category === 'flase'){
		$query .= 'post_type=mp_service&showposts='.$posts;
	}
	else {$query .= 'post_type=mp_service&mp_specifics='.$category.'&showposts='.$posts;}
	if(!empty($query)){
		$query .= $query;
	}
	$wp_query->query($query);
	ob_start();
	?>
    <div class="mp-wrap">
	<ul class="mpbox col<?php echo $columns ?> <?php echo $layout ?> <?php echo $type ?>">
	<?php while ($wp_query->have_posts()) : $wp_query->the_post();?>
            
			<?php 
                $service_icon = get_post_meta(get_the_ID(), 'themnific_service_icon', true);
                $service_link = get_post_meta(get_the_ID(), 'themnific_service_link', true);
                $button_label = get_post_meta(get_the_ID(), 'themnific_button_label', true);
            ?>
                  
                <li class="mp-services tranz">
                
                	<div class="mp-inner tranz <?php if ($service_icon) {echo 'with-icon';} ?>">
                            
                        <?php if($service_icon) {?><i class="main rad ribbon tranz <?php echo esc_attr($service_icon);?>"></i><?php }?>
                        
                        <?php if ($service_link) { ?>
                    
                    		<h3>
                            
                                <a href="<?php echo esc_url($service_link); ?>"><?php the_title(  ); ?></a>
                            
                            </h3>
                            
                            <div class="mp-service-media">
                                
                                <a href="<?php echo esc_url($service_link); ?>"><?php the_post_thumbnail('mp-service', array('class' => 'service-thumb')); ?></a>
                            
                            </div>
                            
                        <?php } else { ?>
                        
							<h3>  
                            
                                <?php the_title(  ); ?>
                            
                            </h3>
                            
                            <div class="mp-service-media">
                    
								<?php the_post_thumbnail('mp-service', array('class' => 'service-thumb')); ?>
                                
                            </div>
                            
                        <?php } ?>       
                               
                        <?php the_content(); ?>
                        
                        <?php if ($service_link) { ?><a class="mp-more rad ribbon tranz" href="<?php echo esc_url($service_link); ?>"><?php echo esc_attr($button_label) ?> <i class="fa fa-angle-right"></i>
</a><?php } ?>   
                    
                    </div>
                    
                </li>
            
	<?php endwhile; ?>
    </ul>
    </div> 
    <div class="clearfix"></div>
    <?php wp_reset_query(); ?>
	<?php $wp_query = null; $wp_query = $temp;
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}
add_shortcode("mp-services", "mp_services");



/*-----------------------------------------------------------------------------------*/
/* [mc-staff]
/*-----------------------------------------------------------------------------------*/

function mc_staff($atts, $content = null) {
	extract(shortcode_atts(array(
		"query" => '',
        "category" => '',
		"posts" => '',
		"columns" => '3',
		"layout" => '' /* 0 / simple */,
		"type" => '' /* 0 / boxed */,
	), $atts));
	global $wp_query,$paged,$post;
	$temp = $wp_query;
	$wp_query= null;
	$wp_query = new WP_Query();
	if($category === 'flase'){
		$query .= 'post_type=mp_staff&showposts='.$posts;
	}
	else {$query .= 'post_type=mp_staff&mp_teams='.$category.'&showposts='.$posts;}
	if(!empty($query)){
		$query .= $query;
	}
	$wp_query->query($query);
	ob_start();
	?>
    <div class="mp-wrap">
	<ul class="mpbox col<?php echo $columns ?> <?php echo $layout ?> <?php echo $type ?>">
	<?php while ($wp_query->have_posts()) : $wp_query->the_post();?>
            
			<?php 
			$staff_position = get_post_meta(get_the_ID(), 'themnific_staff_position', true);
			$staff_website = get_post_meta(get_the_ID(), 'themnific_staff_website', true);
			$staff_phone = get_post_meta(get_the_ID(), 'themnific_staff_phone', true);
			$staff_email = get_post_meta(get_the_ID(), 'themnific_staff_email', true);
			
			$staff_facebook = get_post_meta(get_the_ID(), 'themnific_staff_facebook', true);
			$staff_twitter = get_post_meta(get_the_ID(), 'themnific_staff_twitter', true);
			$staff_google = get_post_meta(get_the_ID(), 'themnific_staff_google', true);
			$staff_linkedin = get_post_meta(get_the_ID(), 'themnific_staff_linkedin', true);
			$staff_pinterest = get_post_meta(get_the_ID(), 'themnific_staff_pinterest', true);
			$staff_flickr = get_post_meta(get_the_ID(), 'themnific_staff_flickr', true);
			$staff_instagram = get_post_meta(get_the_ID(), 'themnific_staff_instagram', true);
			$staff_vk = get_post_meta(get_the_ID(), 'themnific_staff_vk', true);
            ?>
            
            <?php $mc_target = get_option('themnific_mc_target'); ?>
                  
                <li class="mc-staff tranz">
                
                	<div class="mc-inner tranz">
                        
                        <?php if ($staff_website) { ?>
                    
                           	<a href="<?php echo esc_url($staff_website); ?>"><?php the_post_thumbnail('cityofwp_small'); ?></a>
                                
                        <?php } else { ?>

							<?php the_post_thumbnail('cityofwp_small'); ?>
                            
                        <?php } ?>   
                        
                        <div class="staff-inner"> 
                            
                            <div class="staff-meta mc-rad">    
                            
                                <h3>
                                
                                <?php if ($staff_website) { ?>
                    
                           			<a href="<?php echo esc_url($staff_website); ?>"><?php the_title(  ); ?></a>
								
                                <?php } else { ?>
								
									<?php the_title(  ); ?>
                                
                                <?php } ?>   
                                
                                </h3>
                            
                                <p><?php echo esc_attr( $staff_position); ?></p>
                                
                            </div>
                                
                            <div class="staff-content mc-rad"> 
                                   
                                <?php the_content(); ?>
                            
                            </div>                       
                            
                            <ul class="mc-staff-social <?php if (get_option('masterposts_staff_target') == 'false' ); else echo 'in-new-window'; ?>">
                            
                                <?php if($staff_phone) {?><li><i class="fa fa-phone" aria-hidden="true"></i> <?php echo esc_attr($staff_phone) ?></li><?php } else {}?>
                            
                                <?php if($staff_email) {?><li><a title="Email" class="staffmail" href="mailto:<?php echo (esc_attr($staff_email)); ?>"><i class="fa fa-envelope"></i> <?php echo (esc_attr($staff_email)); ?></a></li><?php } else {}?>
                        
                                <?php if($staff_facebook) {?><li><a title="Facebook" class="" href="<?php echo (esc_url($staff_facebook)); ?>"><i class="fa fa-facebook-square"></i></a></li><?php } else {}?>
                                <?php if($staff_twitter) {?><li><a title="Twitter" class="" href="<?php echo (esc_url($staff_twitter)); ?>"><i class="fa fa-twitter"></i></a></li><?php } else {}?>
                                <?php if($staff_google) {?><li><a title="Google" class="" href="<?php echo (esc_url($staff_google)); ?>"><i class="fa fa-google-plus"></i></a></li><?php } else {}?>
                                <?php if($staff_linkedin) {?><li><a title="LinkedIn" class="" href="<?php echo (esc_url($staff_linkedin)); ?>"><i class="fa fa-linkedin"></i></a></li><?php } else {}?>
                                <?php if($staff_pinterest) {?><li><a title="Pinterest" class="" href="<?php echo (esc_url($staff_pinterest)); ?>"><i class="fa fa-pinterest"></i></a></li><?php } else {}?>
                                <?php if($staff_flickr) {?><li><a title="Flickr" class="" href="<?php echo (esc_url($staff_flickr)); ?>"><i class="fa fa-flickr"></i></a></li><?php } else {}?>
                                <?php if($staff_instagram) {?><li><a title="Instagram" class="" href="<?php echo (esc_url($staff_instagram)); ?>"><i class="fa fa-instagram"></i></a></li><?php } else {}?>
                                <?php if($staff_vk) {?><li><a title="VK" class="" href="<?php echo (esc_url($staff_vk)); ?>"><i class="fa fa-vk"></i></a></li><?php } else {}?>
                        
                            </ul> 
                            
                            
                    	</div>
                    
                    </div>
                    
                </li>
            
	<?php endwhile; ?>
    </ul>
    </div> 
    <div class="clearfix"></div>
    <?php wp_reset_query(); ?>
	<?php $wp_query = null; $wp_query = $temp;
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}
add_shortcode("mc-staff", "mc_staff");




/*-----------------------------------------------------------------------------------*/
/* [mc-slider]
/*-----------------------------------------------------------------------------------*/

function mc_slider($atts, $content = null) {
	extract(shortcode_atts(array(
		"query" => '',
        "category" => '',
		"posts" => '',
	), $atts));
	$master_posts_main_file = dirname(__FILE__).'/master-posts.php';
	$master_posts_directory = plugin_dir_url($master_posts_main_file);
	$master_posts_path = dirname(__FILE__);
	wp_enqueue_script('jquery.flexslider-min', $master_posts_directory.'js/jquery.flexslider-min.js','','', true);
	wp_enqueue_script('jquery.flexslider.mp.start', $master_posts_directory.'js/jquery.flexslider.mp.start.js','','', true);
	global $wp_query,$paged,$post;
	$temp = $wp_query;
	$wp_query= null;
	$wp_query = new WP_Query();
	if($category === 'flase'){
		$query .= 'post_type=slider&showposts='.$posts;
	}
	else {$query .= 'post_type=slider&groups='.$category.'&showposts='.$posts;}
	if(!empty($query)){
		$query .= $query;
	}
	$wp_query->query($query);
	ob_start();
	?>
    <div class="mainflex flexslider loading">
    <ul class="slides" >
	<?php while ($wp_query->have_posts()) : $wp_query->the_post();?>
            
			<?php 
                $project_url = get_post_meta(get_the_ID(), 'themnific_project_url', true);
            ?>
                  
			<li>
                
                <?php if ( has_post_thumbnail()) { ?>
                    
                         <a href="<?php echo (esc_url($project_url)); ?>" title="<?php the_title();?>" >
                         
                            <?php the_post_thumbnail( 'work', array('class' => 'tranz')); ?>
                            
                         </a>
                    
                <?php } ?>
                
                <div class="flexinside tranz ">
                
                	<h2><a href="<?php echo (esc_url($project_url)); ?>" title="<?php the_title();?>" ><?php the_title();?></a></h2>
                
                	<div class="hrline"></div>
                
                    <?php the_content(); ?>
                
                </div>
                        
			</li>
            
	<?php endwhile; ?>
    </ul>
    </div> 
    <div class="clearfix"></div>
    <?php wp_reset_query(); ?>
	<?php $wp_query = null; $wp_query = $temp;
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}
add_shortcode("mc-slider", "mc_slider");

/*-----------------------------------------------------------------------------------*/
/* THE END */
/*-----------------------------------------------------------------------------------*/
?>